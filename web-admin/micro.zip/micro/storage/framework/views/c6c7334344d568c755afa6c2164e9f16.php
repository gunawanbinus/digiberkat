<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
    <div class="row">
      <div class="col-md-3">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Welcome, <?php echo e(currentUser('username') ?? 'Guest'); ?></h5>
            <p class="card-text">Your account dashboard</p>
            <a href="<?php echo e(route('account')); ?>" class="btn btn-primary">Go to Account</a>
          </div>
        </div>
      </div>

      <div class="col-md-9">
        <div class="card">
          <div class="card-body">
            <h4 class="card-title">About Me</h4>
            <p>Welcome to your dashboard. This is where you can update your profile and personal information.</p>
            <a href="<?php echo e(route('account')); ?>" class="btn btn-info">Update Account Info</a>
            <a href="<?php echo e(url('/productss')); ?>" class="btn btn-success mt-3">Go to Products</a>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\MataKuliahSem4\WebProgramming\microweb\micro\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>