<?php $__env->startSection('title', 'Semua Produk'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <div class="row">
    <div class="col-md-12">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h2>Semua Produk</h2>
        <a href="" class="btn btn-primary">Tambah Produk</a>
      </div>
      <p class="text-muted">Klik pada kepala tabel untuk mengurutkan berdasarkan kolom. Klik pada produk untuk mengedit.</p>

    <div class="table-responsive">
        <table class="table table-bordered table-hover" id="productTable">
            <thead class="table-light">
                <tr>
                    <th >ID</th>
                    <th>Gambar</th>
                    <th >Nama</th>
                    <th >Varian</th>
                    <th >Harga Normal</th>
                    <th >Harga Diskon</th>
                    <th >Stok</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($product['is_varians']): ?>
                        <?php $__currentLoopData = $product['variants']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr onclick="location.href='/products/<?php echo e($product['id']); ?>'" style="cursor: pointer;">
                                <td><?php echo e($product['id']); ?></td>
                                <td>
                                    <img src="<?php echo e($product['thumbnails'][0] ?? ''); ?>" width="50">
                                </td>
                                <td><?php echo e($product['name']); ?></td>
                                <td><?php echo e($variant['name']); ?></td>
                                <td>Rp<?php echo e(number_format($variant['price'], 0, ',', '.')); ?></td>
                                <td>
                                    <?php echo e($variant['discount_price'] ? 'Rp' . number_format($variant['discount_price'], 0, ',', '.') : '-'); ?>

                                </td>
                                <td><?php echo e($variant['stock']); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr onclick="location.href='/products/<?php echo e($product['id']); ?>'" style="cursor: pointer;">
                            <td><?php echo e($product['id']); ?></td>
                            <td>
                                <img src="<?php echo e($product['thumbnails'][0] ?? ''); ?>" width="50">
                            </td>
                            <td><?php echo e($product['name']); ?></td>
                            <td>-</td>
                            <td>Rp<?php echo e(number_format($product['price'], 0, ',', '.')); ?></td>
                            <td>
                                <?php echo e($product['discount_price'] ? 'Rp' . number_format($product['discount_price'], 0, ',', '.') : '-'); ?>

                            </td>
                            <td><?php echo e($product['stock']); ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function sortTable(n) {
    const table = document.getElementById("productTable");
    let switching = true, dir = "asc", switchcount = 0;

    while (switching) {
        switching = false;
        const rows = table.rows;

        for (let i = 1; i < (rows.length - 1); i++) {
            let shouldSwitch = false;
            const x = rows[i].getElementsByTagName("TD")[n];
            const y = rows[i + 1].getElementsByTagName("TD")[n];

            let xContent = x.innerText || x.textContent;
            let yContent = y.innerText || y.textContent;

            const xNum = parseFloat(xContent.replace(/[^\d.]/g, '')) || 0;
            const yNum = parseFloat(yContent.replace(/[^\d.]/g, '')) || 0;

            const compareResult = (!isNaN(xNum) && !isNaN(yNum)) ?
                (dir === "asc" ? xNum > yNum : xNum < yNum) :
                (dir === "asc" ? xContent.toLowerCase() > yContent.toLowerCase() : xContent.toLowerCase() < yContent.toLowerCase());

            if (compareResult) {
                shouldSwitch = true;
                break;
            }
        }

        if (shouldSwitch) {
            rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
            switching = true;
            switchcount++;
        } else if (switchcount === 0 && dir === "asc") {
            dir = "desc";
            switching = true;
        }
    }
}

window.onload = function () {
    sortTable(6); // sort by stock
}
</script>

    <!-- jQuery dan DataTables JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#productTable').DataTable({
                order: [[6, 'asc']],
                language: {
                    url: '//cdn.datatables.net/plug-ins/1.13.4/i18n/id.json'
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kubuntu/digiberkat/web-admin/micro/resources/views/products/index.blade.php ENDPATH**/ ?>