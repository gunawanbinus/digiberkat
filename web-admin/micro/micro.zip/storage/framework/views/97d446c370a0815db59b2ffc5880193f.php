<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
  <div class="row">
    <div class="col-md-12">
      <h2 class="mb-4">Dashboard Admin</h2>

      <div class="row">
        <!-- Pending Orders -->
        <div class="col-md-6">
          <div class="card mb-4">
            <div class="card-header d-flex justify-content-between">
              <span>Pesanan Pending</span>
              <a href="/orders?status=pending">Lihat semua</a>
            </div>
            <div class="card-body" style="max-height: 300px; overflow-y: auto">
              <ul class="list-group list-group-flush">
                <?php $__currentLoopData = $pendingOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="list-group-item list-group-item-action" onclick="location.href='/orders/<?php echo e($item['order']['id']); ?>'">
                    <div class="d-flex align-items-center">
                      <img src="<?php echo e($item['sample_item']['thumbnail']); ?>" width="40" height="40" class="me-2 rounded">
                      <div>
                        <div>#<?php echo e($item['order']['id']); ?> - Rp<?php echo e(number_format($item['order']['total_price'])); ?></div>
                        <small class="text-muted"><?php echo e($item['sample_item']['product_name']); ?> - <?php echo e(\Carbon\Carbon::parse($item['order']['created_at'])->format('d M Y')); ?></small>
                      </div>
                    </div>
                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          </div>
        </div>

        <!-- Low Stock Products -->
        <div class="col-md-6">
          <div class="card mb-4">
            <div class="card-header d-flex justify-content-between">
              <span>Stok Rendah</span>
              <a href="/products">Lihat semua</a>
            </div>
            <div class="card-body" style="max-height: 300px; overflow-y: auto">
              <ul class="list-group list-group-flush">
                <?php $__currentLoopData = $lowStocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="list-group-item list-group-item-action" onclick="location.href='/products/<?php echo e($prod['product_id']); ?>'">
                    <div class="d-flex align-items-center">
                      <img src="<?php echo e($prod['thumbnail']); ?>" width="40" height="40" class="me-2 rounded">
                      <div>
                        <div><?php echo e($prod['product_name']); ?> - <?php echo e($prod['variant_name']); ?></div>
                        <small class="text-danger">Stok: <?php echo e($prod['stock']); ?></small>
                      </div>
                    </div>
                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <!-- Sales Chart (full width) -->
      <div class="row">
        <div class="col-md-12">
          <div class="card mb-4">
            <div class="card-header">Penjualan per Bulan</div>
            <div class="card-body">
              <canvas id="salesChart" style="height: 300px;"></canvas>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
  const sales = <?php echo json_encode($sales, 15, 512) ?>;
  const labels = sales.map(d => d.month);
  const values = sales.map(d => d.total_sales);

  if (labels.length > 0) {
    new Chart(document.getElementById('salesChart'), {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [{
          label: 'Total Penjualan',
          data: values,
          backgroundColor: 'rgba(54, 162, 235, 0.6)'
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          title: { display: false }
        },
        scales: {
          y: { beginAtZero: true }
        }
      }
    });
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/kubuntu/digiberkat/web-admin/micro/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>