<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Produk</title>
    <!-- Tambahkan Bootstrap CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h1 class="mb-4 text-center">Daftar Produk</h1>

    <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col">
                <div class="card h-100 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($product['name']); ?></h5>
                        <p class="card-text"><?php echo e($product['description']); ?></p>

                        <?php if($product['is_discounted'] && $product['discount_price']): ?>
                            <p>
                                <span class="text-danger fw-bold">Rp <?php echo e(number_format($product['discount_price'], 0, ',', '.')); ?></span>
                                <br>
                                <small class="text-muted text-decoration-line-through">Rp <?php echo e(number_format($product['price'], 0, ',', '.')); ?></small>
                            </p>
                        <?php else: ?>
                            <p class="fw-bold">Rp <?php echo e(number_format($product['price'], 0, ',', '.')); ?></p>
                        <?php endif; ?>

                        <p class="text-muted">Stok: <?php echo e($product['stock'] ?? '-'); ?></p>

                        <a href="#" class="btn btn-primary w-100">Tambahkan ke Keranjang</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="alert alert-warning text-center">Tidak ada produk ditemukan.</div>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH D:\MataKuliahSem4\WebProgramming\microweb\micro\resources\views/products/index.blade.php ENDPATH**/ ?>